
=== GREETINGS ===
=== GREETINGS BOLD ===



Keith Bates / K-Type © 2001, 2017 (version 4.0)
www.k-type.com    -    info@k-type.com

Two pointy semi-serif fonts with an old-fashioned feel, loosely inspired by the cover lettering of 'My Book About Christmas' by Joan Gale Thomas, 1946. The 2017 versions of both fonts offer significant outline and spacing improvements.

Greetings and Greetings Bold are Free for Personal Use.

------------------------------------------------

== Licence Information ==

Licence URL: http://www.k-type.com/licences

------------------------------------------------

== Installing Fonts ==

Fonts are placed in your operating system's Fonts folder and will be made available to all the applications or programs you use.

= Windows =
Put the .ttf or .otf font file into C:\Windows\Fonts, or right-click on the font files > Install

= Mac =
Put the .ttf or .otf font file into /Library/Fonts

------------------------------------------------